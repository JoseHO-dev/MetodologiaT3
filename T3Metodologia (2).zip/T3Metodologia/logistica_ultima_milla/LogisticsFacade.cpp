#include "LogisticsFacade.h"
#include <chrono>
#include <iostream>
#include <random>

namespace ultima_milla {

void EventLogger::log(const std::string& message) {
    auto now = std::chrono::system_clock::now();
    auto time = std::chrono::system_clock::to_time_t(now);
    std::string timestamp = std::ctime(&time);
    if (!timestamp.empty() && timestamp.back() == '\n') {
        timestamp.pop_back();
    }
    std::string entry = "[" + timestamp + "] " + message;
    log_entries_.push_back(entry);
    std::cout << "  LOG: " << entry << "\n";
}

const std::vector<std::string>& EventLogger::get_events() const {
    return log_entries_;
}

std::pair<bool, std::vector<std::string>> OrderValidator::validate(const Order& order) const {
    std::vector<std::string> errors;
    if (!order.origin.has_value() || !order.origin->is_valid()) {
        errors.push_back("Direccion de origen invalida o fuera del dominio [1-100].");
    }
    if (!order.destination.has_value() || !order.destination->is_valid()) {
        errors.push_back("Direccion de destino invalida o fuera del dominio [1-100].");
    }
    if (order.recipient_name.empty()) {
        errors.push_back("Falta nombre del destinatario.");
    }
    if (order.contact_medium.empty()) {
        errors.push_back("Falta medio de contacto.");
    }
    if (order.cargo_type.empty()) {
        errors.push_back("Falta tipo de carga.");
    }
    if (order.weight_kg <= 0.0f) {
        errors.push_back("Peso debe ser mayor a 0.");
    }
    if (order.order_id.empty() || order.channel.empty()) {
        errors.push_back("Falta ID unico o canal de origen.");
    }
    return {errors.empty(), errors};
}

bool OrderStateManager::transition(Order& order, OrderStatus new_status) {
    static const std::map<OrderStatus, std::vector<OrderStatus>> transitions = {
        {OrderStatus::CREADO, {OrderStatus::VALIDADO, OrderStatus::CANCELADO}},
        {OrderStatus::VALIDADO, {OrderStatus::PENDIENTE_ASIGNACION, OrderStatus::CANCELADO}},
        {OrderStatus::PENDIENTE_ASIGNACION, {OrderStatus::ASIGNADO, OrderStatus::CANCELADO}},
        {OrderStatus::ASIGNADO, {OrderStatus::EN_RUTA, OrderStatus::PENDIENTE_ASIGNACION, OrderStatus::CANCELADO}},
        {OrderStatus::EN_RUTA, {OrderStatus::ENTREGADO, OrderStatus::INTENTO_FALLIDO, OrderStatus::CANCELADO}},
        {OrderStatus::INTENTO_FALLIDO, {OrderStatus::REPROGRAMADO, OrderStatus::CANCELADO}},
        {OrderStatus::REPROGRAMADO, {OrderStatus::ASIGNADO, OrderStatus::CANCELADO}},
        {OrderStatus::ENTREGADO, {}},
        {OrderStatus::CANCELADO, {}},
    };

    auto it = transitions.find(order.status);
    if (it != transitions.end()) {
        const auto& allowed = it->second;
        if (std::find(allowed.begin(), allowed.end(), new_status) != allowed.end()) {
            order.status = new_status;
            order.add_event("Estado -> " + std::to_string(static_cast<int>(new_status)));
            EventLogger::instance().log("Pedido " + order.order_id + ": transicion a nuevo estado");
            return true;
        }
    }
    EventLogger::instance().log("Transicion invalida para pedido " + order.order_id);
    return false;
}

void OrderRepository::save(const Order& order) {
    orders_[order.order_id] = order;
}

std::optional<Order> OrderRepository::get(const std::string& order_id) const {
    auto it = orders_.find(order_id);
    if (it == orders_.end()) {
        return std::nullopt;
    }
    return it->second;
}

std::vector<Order> OrderRepository::all() const {
    std::vector<Order> result;
    result.reserve(orders_.size());
    for (const auto& item : orders_) {
        result.push_back(item.second);
    }
    return result;
}

Courier CourierRepository::register_courier(const std::string& name, float max_volume_m3) {
    Courier courier{next_id_++, name, max_volume_m3};
    couriers_[courier.courier_id] = courier;
    EventLogger::instance().log("Repartidor registrado: " + courier.name);
    return courier;
}

std::vector<Courier> CourierRepository::get_available(float order_volume) const {
    std::vector<Courier> available;
    available.reserve(couriers_.size());
    for (const auto& item : couriers_) {
        if (item.second.can_accept(order_volume)) {
            available.push_back(item.second);
        }
    }
    return available;
}

std::optional<Courier> CourierRepository::get_by_id(int courier_id) const {
    auto it = couriers_.find(courier_id);
    if (it == couriers_.end()) {
        return std::nullopt;
    }
    return it->second;
}

bool CourierRepository::assign_order(int courier_id, const std::string& order_id, float order_volume) {
    auto it = couriers_.find(courier_id);
    if (it == couriers_.end()) {
        return false;
    }
    it->second.assign_order(order_id, order_volume);
    return true;
}

bool CourierRepository::update_location(int courier_id, int location) {
    auto it = couriers_.find(courier_id);
    if (it == couriers_.end()) {
        return false;
    }
    bool ok = it->second.update_location(location);
    if (ok) {
        EventLogger::instance().log("Repartidor " + std::to_string(courier_id) + " ubicacion actualizada");
    }
    return ok;
}

void CourierRepository::set_availability(int courier_id, bool available) {
    auto it = couriers_.find(courier_id);
    if (it != couriers_.end()) {
        it->second.available = available;
    }
}

std::vector<Courier> CourierRepository::all() const {
    std::vector<Courier> result;
    result.reserve(couriers_.size());
    for (const auto& item : couriers_) {
        result.push_back(item.second);
    }
    return result;
}

Route RouteManager::define_route(const std::vector<std::string>& order_ids) {
    std::string route_id = "RUTA-" + std::to_string(next_id_++);
    std::random_device rd;
    std::mt19937 rng(rd());
    std::uniform_int_distribution<int> dist(1, 100);
    Route route{route_id, order_ids, dist(rng), true, {}};
    routes_[route_id] = route;
    EventLogger::instance().log("Ruta definida: " + route_id);
    return route;
}

bool RouteManager::adjust_route(const std::string& route_id, const std::string& new_order_id,
                                const OrderRepository& order_repo) {
    auto it = routes_.find(route_id);
    if (it == routes_.end() || !it->second.active) {
        return false;
    }
    Route& route = it->second;
    if (std::find(route.order_ids.begin(), route.order_ids.end(), new_order_id) != route.order_ids.end()) {
        return false;
    }
    route.order_ids.push_back(new_order_id);
    std::sort(route.order_ids.begin(), route.order_ids.end(),
              [&order_repo](const std::string& lhs, const std::string& rhs) {
                  auto lo = order_repo.get(lhs);
                  auto ro = order_repo.get(rhs);
                  int ln = lo && lo->destination ? lo->destination->number : 999;
                  int rn = ro && ro->destination ? ro->destination->number : 999;
                  return ln < rn;
              });
    std::random_device rd;
    std::mt19937 rng(rd());
    std::uniform_int_distribution<int> dist(1, 100);
    route.best_score = dist(rng);
    route.tracking_log.push_back("Ajuste: pedido " + new_order_id);
    EventLogger::instance().log("Ruta ajustada: " + route_id);
    return true;
}

bool RouteManager::track_route(const std::string& route_id, const std::string& event) {
    auto it = routes_.find(route_id);
    if (it == routes_.end()) {
        return false;
    }
    it->second.tracking_log.push_back(event);
    EventLogger::instance().log("Seguimiento ruta " + route_id + ": " + event);
    return true;
}

std::optional<Route> RouteManager::get_route(const std::string& route_id) const {
    auto it = routes_.find(route_id);
    if (it == routes_.end()) {
        return std::nullopt;
    }
    return it->second;
}

std::vector<Route> RouteManager::all() const {
    std::vector<Route> result;
    result.reserve(routes_.size());
    for (const auto& item : routes_) {
        result.push_back(item.second);
    }
    return result;
}

Order LogisticsFacade::crear_pedido(const std::string& order_id,
                                   const Address& origin,
                                   const Address& destination,
                                   const std::string& recipient_name,
                                   const std::string& contact,
                                   DeliveryType delivery_type,
                                   const std::string& cargo_type,
                                   float weight_kg,
                                   const std::string& channel) {
    Order order;
    order.order_id = order_id;
    order.channel = channel;
    order.origin = origin;
    order.destination = destination;
    order.recipient_name = recipient_name;
    order.contact_medium = contact;
    order.delivery_type = delivery_type;
    order.cargo_type = cargo_type;
    order.weight_kg = weight_kg;
    order_repo_.save(order);
    EventLogger::instance().log("Pedido creado: " + order_id);
    return order;
}

std::pair<bool, std::vector<std::string>> LogisticsFacade::validar_pedido(const std::string& order_id) {
    auto order_opt = order_repo_.get(order_id);
    if (!order_opt) {
        return {false, {"Pedido no existe."}};
    }
    auto [ok, errors] = validator_.validate(*order_opt);
    if (ok) {
        Order order = *order_opt;
        state_manager_.transition(order, OrderStatus::VALIDADO);
        state_manager_.transition(order, OrderStatus::PENDIENTE_ASIGNACION);
        order_repo_.save(order);
    }
    return {ok, errors};
}

bool LogisticsFacade::asignar_pedido(const std::string& order_id, float order_volume) {
    auto order_opt = order_repo_.get(order_id);
    if (!order_opt || order_opt->status != OrderStatus::PENDIENTE_ASIGNACION) {
        return false;
    }
    auto available = courier_repo_.get_available(order_volume);
    if (available.empty()) {
        return false;
    }
    const Courier& courier = available.front();
    bool assigned = courier_repo_.assign_order(courier.courier_id, order_id, order_volume);
    if (!assigned) {
        return false;
    }
    Order order = *order_opt;
    order.assigned_courier_id = courier.courier_id;
    state_manager_.transition(order, OrderStatus::ASIGNADO);
    order_repo_.save(order);
    EventLogger::instance().log("Pedido " + order_id + " asignado a repartidor " + std::to_string(courier.courier_id));
    return true;
}

Route LogisticsFacade::definir_ruta(const std::vector<std::string>& order_ids) {
    return route_manager_.define_route(order_ids);
}

bool LogisticsFacade::ajustar_ruta_dinamicamente(const std::string& route_id, const std::string& new_order_id) {
    return route_manager_.adjust_route(route_id, new_order_id, order_repo_);
}

bool LogisticsFacade::seguimiento_ruta(const std::string& route_id, const std::string& event) {
    return route_manager_.track_route(route_id, event);
}

std::optional<Order> LogisticsFacade::obtener_pedido(const std::string& order_id) const {
    return order_repo_.get(order_id);
}

std::optional<Courier> LogisticsFacade::obtener_repartidor(int courier_id) const {
    return courier_repo_.get_by_id(courier_id);
}

std::optional<Route> LogisticsFacade::obtener_ruta(const std::string& route_id) const {
    return route_manager_.get_route(route_id);
}

} // namespace ultima_milla
