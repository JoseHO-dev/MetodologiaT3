import queue
import threading
import time
from dataclasses import dataclass
from typing import List, Optional

from .domain import EventLogger
from .repositories import OrderRepository, RouteManager


@dataclass(frozen=True)
class RouteTask:
    action: str
    route_id: Optional[str] = None
    order_ids: Optional[List[str]] = None
    new_order_id: Optional[str] = None
    event: Optional[str] = None


class RouteTaskProcessor:
    def __init__(self, route_manager: RouteManager, order_repo: OrderRepository) -> None:
        self._route_manager = route_manager
        self._order_repo = order_repo
        self._queue: queue.Queue[RouteTask] = queue.Queue()
        self._thread = threading.Thread(target=self._run, daemon=True, name="RouteTaskProcessor")
        self._thread.start()
        EventLogger().log("RouteTaskProcessor iniciado.")

    def enqueue_adjust_route(self, route_id: str, new_order_id: str) -> bool:
        task = RouteTask(action="adjust_route", route_id=route_id, new_order_id=new_order_id)
        self._queue.put(task)
        EventLogger().log(f"Tarea encolada: ajustar ruta {route_id} con pedido {new_order_id}.")
        return True

    def enqueue_track_route(self, route_id: str, event: str) -> bool:
        task = RouteTask(action="track_route", route_id=route_id, event=event)
        self._queue.put(task)
        EventLogger().log(f"Tarea encolada: seguimiento ruta {route_id} -> {event}.")
        return True

    def _run(self) -> None:
        while True:
            task = self._queue.get()
            try:
                self._process(task)
            except Exception as exc:
                EventLogger().log(f"Error procesando tarea de ruta: {exc}")
            finally:
                self._queue.task_done()
            time.sleep(0.01)

    def _process(self, task: RouteTask) -> None:
        if task.action == "adjust_route":
            if task.route_id and task.new_order_id:
                self._route_manager.adjust_route(task.route_id, task.new_order_id, self._order_repo)
                EventLogger().log(f"Tarea procesada: ajustar ruta {task.route_id}.")
        elif task.action == "track_route":
            if task.route_id and task.event:
                self._route_manager.track_route(task.route_id, task.event)
                EventLogger().log(f"Tarea procesada: seguimiento ruta {task.route_id}.")
        else:
            EventLogger().log(f"Tarea no reconocida: {task.action}")
