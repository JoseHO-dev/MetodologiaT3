from __future__ import annotations
from typing import Optional
from .domain import Courier, EventLogger, Order, Route, ROUTE_DOMAIN_MIN, ROUTE_DOMAIN_MAX
import random


class OrderRepository:
    def __init__(self) -> None:
        self._orders: dict[str, Order] = {}

    def save(self, order: Order) -> None:
        self._orders[order.order_id] = order

    def get(self, order_id: str) -> Optional[Order]:
        return self._orders.get(order_id)

    def all(self) -> list[Order]:
        return list(self._orders.values())


class CourierRepository:
    def __init__(self) -> None:
        self._couriers: dict[int, Courier] = {}
        self._next_id: int = 1

    def register(self, name: str, max_volume_m3: float) -> Courier:
        courier = Courier(courier_id=self._next_id, name=name, max_volume_m3=max_volume_m3)
        self._couriers[self._next_id] = courier
        self._next_id += 1
        EventLogger().log(f"Repartidor registrado: {name} (ID={courier.courier_id}, vol_max={max_volume_m3}m3)")
        return courier

    def get_available(self, order_volume: float = 0.0) -> list[Courier]:
        return [c for c in self._couriers.values() if c.can_accept(order_volume)]

    def get_by_id(self, courier_id: int) -> Optional[Courier]:
        return self._couriers.get(courier_id)

    def update_location(self, courier_id: int, location: int) -> bool:
        courier = self.get_by_id(courier_id)
        if not courier:
            print(f"  ERROR: Repartidor {courier_id} no existe.")
            return False
        ok = courier.update_location(location)
        if ok:
            EventLogger().log(f"Repartidor {courier_id} ({courier.name}) ubicacion -> {location}")
        else:
            print(f"  ERROR: Ubicacion {location} fuera del dominio [{ROUTE_DOMAIN_MIN}-{ROUTE_DOMAIN_MAX}].")
        return ok

    def set_availability(self, courier_id: int, available: bool) -> None:
        courier = self.get_by_id(courier_id)
        if courier:
            courier.available = available
            estado = "disponible" if available else "no disponible"
            EventLogger().log(f"Repartidor {courier_id} ({courier.name}) -> {estado}")

    def all(self) -> list[Courier]:
        return list(self._couriers.values())


class RouteManager:
    def __init__(self) -> None:
        self._routes: dict[str, Route] = {}
        self._next_id: int = 1

    def define_route(self, order_ids: list[str]) -> Route:
        route_id = f"RUTA-{self._next_id:03d}"
        score = random.randint(ROUTE_DOMAIN_MIN, ROUTE_DOMAIN_MAX)
        route = Route(route_id=route_id, order_ids=list(order_ids), best_score=score)
        self._routes[route_id] = route
        self._next_id += 1
        EventLogger().log(f"Ruta definida: {route_id} | pedidos={order_ids} | score={score}")
        return route

    def adjust_route(self, route_id: str, new_order_id: str, order_repo: OrderRepository) -> bool:
        route = self._routes.get(route_id)
        if not route or not route.active:
            print(f"  ERROR: Ruta {route_id} no existe o no esta activa.")
            return False
        if new_order_id in route.order_ids:
            print(f"  AVISO: Pedido {new_order_id} ya esta en la ruta.")
            return False
        route.order_ids.append(new_order_id)

        def dest_number(oid: str) -> int:
            order = order_repo.get(oid)
            return order.destination.number if (order and order.destination) else 999

        route.order_ids.sort(key=dest_number)
        route.best_score = random.randint(ROUTE_DOMAIN_MIN, ROUTE_DOMAIN_MAX)
        route.tracking_log.append(
            f"Ajuste: pedido {new_order_id} agregado | orden={route.order_ids} | score={route.best_score}"
        )
        EventLogger().log(
            f"Ruta {route_id} ajustada -> orden={route.order_ids} | score={route.best_score}"
        )
        return True

    def track_route(self, route_id: str, event: str) -> bool:
        route = self._routes.get(route_id)
        if not route:
            return False
        route.tracking_log.append(event)
        EventLogger().log(f"Seguimiento {route_id}: {event}")
        return True

    def get_route(self, route_id: str) -> Optional[Route]:
        return self._routes.get(route_id)

    def all(self) -> list[Route]:
        return list(self._routes.values())
