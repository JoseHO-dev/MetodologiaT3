#pragma once

#include <algorithm>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace ultima_milla {

enum class OrderStatus {
    CREADO,
    VALIDADO,
    PENDIENTE_ASIGNACION,
    ASIGNADO,
    EN_RUTA,
    INTENTO_FALLIDO,
    REPROGRAMADO,
    ENTREGADO,
    CANCELADO,
};

enum class DeliveryType {
    NORMAL,
    EXPRESS,
    PROGRAMADA,
};

struct Address {
    std::string street;
    int number;
    std::string city;

    bool is_valid() const {
        return number >= 1 && number <= 100;
    }
};

struct Order {
    std::string order_id;
    std::string channel;
    std::optional<Address> origin;
    std::optional<Address> destination;
    std::string recipient_name;
    std::string contact_medium;
    DeliveryType delivery_type = DeliveryType::NORMAL;
    std::string cargo_type;
    float weight_kg = 0.0f;
    OrderStatus status = OrderStatus::CREADO;
    std::optional<int> assigned_courier_id;
    std::optional<std::string> route_id;
    std::vector<std::string> events;

    void add_event(const std::string& event) {
        events.push_back(event);
    }
};

struct Courier {
    int courier_id;
    std::string name;
    float max_volume_m3;
    bool available = true;
    float current_volume = 0.0f;
    std::vector<std::string> current_orders;
    int location = 50;

    bool can_accept(float order_volume) const {
        return available && (current_volume + order_volume) <= max_volume_m3;
    }

    void assign_order(const std::string& order_id, float order_volume) {
        current_orders.push_back(order_id);
        current_volume += order_volume;
    }

    bool update_location(int loc) {
        if (loc >= 1 && loc <= 100) {
            location = loc;
            return true;
        }
        return false;
    }
};

struct Route {
    std::string route_id;
    std::vector<std::string> order_ids;
    int best_score = 0;
    bool active = true;
    std::vector<std::string> tracking_log;
};

class EventLogger {
public:
    static EventLogger& instance() {
        static EventLogger logger;
        return logger;
    }

    void log(const std::string& message);
    const std::vector<std::string>& get_events() const;

private:
    EventLogger() = default;
    std::vector<std::string> log_entries_;
};

class OrderValidator {
public:
    std::pair<bool, std::vector<std::string>> validate(const Order& order) const;
};

class OrderStateManager {
public:
    bool transition(Order& order, OrderStatus new_status);
};

class OrderRepository {
public:
    void save(const Order& order);
    std::optional<Order> get(const std::string& order_id) const;
    std::vector<Order> all() const;

private:
    std::map<std::string, Order> orders_;
};

class CourierRepository {
public:
    Courier register_courier(const std::string& name, float max_volume_m3);
    std::vector<Courier> get_available(float order_volume = 0.0f) const;
    std::optional<Courier> get_by_id(int courier_id) const;
    bool assign_order(int courier_id, const std::string& order_id, float order_volume);
    bool update_location(int courier_id, int location);
    void set_availability(int courier_id, bool available);
    std::vector<Courier> all() const;

private:
    std::map<int, Courier> couriers_;
    int next_id_ = 1;
};

class RouteManager {
public:
    Route define_route(const std::vector<std::string>& order_ids);
    bool adjust_route(const std::string& route_id, const std::string& new_order_id,
                      const OrderRepository& order_repo);
    bool track_route(const std::string& route_id, const std::string& event);
    std::optional<Route> get_route(const std::string& route_id) const;
    std::vector<Route> all() const;

private:
    std::map<std::string, Route> routes_;
    int next_id_ = 1;
};

class LogisticsFacade {
public:
    Order crear_pedido(const std::string& order_id,
                       const Address& origin,
                       const Address& destination,
                       const std::string& recipient_name,
                       const std::string& contact,
                       DeliveryType delivery_type,
                       const std::string& cargo_type,
                       float weight_kg,
                       const std::string& channel);

    std::pair<bool, std::vector<std::string>> validar_pedido(const std::string& order_id);
    bool asignar_pedido(const std::string& order_id, float order_volume = 0.0f);
    Route definir_ruta(const std::vector<std::string>& order_ids);
    bool ajustar_ruta_dinamicamente(const std::string& route_id, const std::string& new_order_id);
    bool seguimiento_ruta(const std::string& route_id, const std::string& event);

    std::optional<Order> obtener_pedido(const std::string& order_id) const;
    std::optional<Courier> obtener_repartidor(int courier_id) const;
    std::optional<Route> obtener_ruta(const std::string& route_id) const;

private:
    OrderRepository order_repo_;
    CourierRepository courier_repo_;
    RouteManager route_manager_;
    OrderValidator validator_;
    OrderStateManager state_manager_;
};

} // namespace ultima_milla
