from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional
import datetime

ROUTE_DOMAIN_MIN = 1
ROUTE_DOMAIN_MAX = 100


class OrderStatus(Enum):
    CREADO = "CREADO"
    VALIDADO = "VALIDADO"
    PENDIENTE_ASIGNACION = "PENDIENTE_ASIGNACION"
    ASIGNADO = "ASIGNADO"
    EN_RUTA = "EN_RUTA"
    INTENTO_FALLIDO = "INTENTO_FALLIDO"
    REPROGRAMADO = "REPROGRAMADO"
    ENTREGADO = "ENTREGADO"
    CANCELADO = "CANCELADO"


class DeliveryType(Enum):
    NORMAL = "NORMAL"
    EXPRESS = "EXPRESS"
    PROGRAMADA = "PROGRAMADA"


class Channel(Enum):
    CANAL_PROPIO = "CANAL_PROPIO"
    ECOMMERCE = "ECOMMERCE"


@dataclass(frozen=True)
class Address:
    street: str
    number: int
    city: str

    def is_valid(self) -> bool:
        return ROUTE_DOMAIN_MIN <= self.number <= ROUTE_DOMAIN_MAX


class IAddressAdapter(ABC):
    @abstractmethod
    def adapt(self, raw: dict) -> Address: ...


class ExternalAddressAdapter(IAddressAdapter):
    def adapt(self, raw: dict) -> Address:
        try:
            number = int(raw.get("nro", -1))
        except (ValueError, TypeError):
            number = -1
        return Address(
            street=str(raw.get("calle", "")),
            number=number,
            city=str(raw.get("ciudad", "")),
        )


class EventLogger:
    _instance: Optional[EventLogger] = None

    def __new__(cls) -> EventLogger:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._log = []
        return cls._instance

    def log(self, message: str) -> None:
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        entry = f"[{ts}] {message}"
        self._log.append(entry)
        print(f"  LOG: {entry}")

    def get_events(self) -> list[str]:
        return list(self._log)


@dataclass
class Order:
    order_id: str
    channel: Channel
    origin: Optional[Address] = None
    destination: Optional[Address] = None
    recipient_name: str = ""
    contact_medium: str = ""
    delivery_type: Optional[DeliveryType] = None
    cargo_type: str = ""
    weight_kg: float = 0.0
    status: OrderStatus = OrderStatus.CREADO
    assigned_courier_id: Optional[int] = None
    route_id: Optional[str] = None
    events: list[str] = field(default_factory=list)

    def add_event(self, event: str) -> None:
        self.events.append(event)


class OrderBuilder:
    def __init__(self, order_id: str, channel: Channel) -> None:
        self._order = Order(order_id=order_id, channel=channel)

    def set_origin(self, address: Address) -> "OrderBuilder":
        self._order.origin = address
        return self

    def set_destination(self, address: Address) -> "OrderBuilder":
        self._order.destination = address
        return self

    def set_recipient(self, name: str, contact: str) -> "OrderBuilder":
        self._order.recipient_name = name
        self._order.contact_medium = contact
        return self

    def set_delivery(self, delivery_type: DeliveryType) -> "OrderBuilder":
        self._order.delivery_type = delivery_type
        return self

    def set_cargo(self, cargo_type: str, weight_kg: float) -> "OrderBuilder":
        self._order.cargo_type = cargo_type
        self._order.weight_kg = weight_kg
        return self

    def build(self) -> Order:
        return self._order


class AbstractChannel(ABC):
    @abstractmethod
    def create_order(self, order_id: str, raw_origin: dict,
                     raw_destination: dict, recipient_name: str,
                     contact: str, delivery_type: DeliveryType,
                     cargo_type: str, weight_kg: float) -> Order: ...


class PropioChannel(AbstractChannel):
    def create_order(self, order_id, raw_origin, raw_destination,
                     recipient_name, contact, delivery_type, cargo_type, weight_kg):
        adapter = ExternalAddressAdapter()
        return (OrderBuilder(order_id, Channel.CANAL_PROPIO)
                .set_origin(adapter.adapt(raw_origin))
                .set_destination(adapter.adapt(raw_destination))
                .set_recipient(recipient_name, contact)
                .set_delivery(delivery_type)
                .set_cargo(cargo_type, weight_kg)
                .build())


class EcommerceChannel(AbstractChannel):
    def create_order(self, order_id, raw_origin, raw_destination,
                     recipient_name, contact, delivery_type, cargo_type, weight_kg):
        adapter = ExternalAddressAdapter()
        return (OrderBuilder(order_id, Channel.ECOMMERCE)
                .set_origin(adapter.adapt(raw_origin))
                .set_destination(adapter.adapt(raw_destination))
                .set_recipient(recipient_name, contact)
                .set_delivery(delivery_type)
                .set_cargo(cargo_type, weight_kg)
                .build())


class INotifiable(ABC):
    @abstractmethod
    def notify(self, recipient: str, message: str) -> None: ...


class SmsNotifier(INotifiable):
    def notify(self, recipient: str, message: str) -> None:
        print(f"  SMS  -> {recipient}: {message}")


class EmailNotifier(INotifiable):
    def notify(self, recipient: str, message: str) -> None:
        print(f"  Email-> {recipient}: {message}")


class AbstractOrderFactory(ABC):
    @abstractmethod
    def get_channel(self) -> AbstractChannel: ...

    @abstractmethod
    def get_notifier(self) -> INotifiable: ...


class PropioFactory(AbstractOrderFactory):
    def get_channel(self) -> AbstractChannel:
        return PropioChannel()

    def get_notifier(self) -> INotifiable:
        return SmsNotifier()


class EcommerceFactory(AbstractOrderFactory):
    def get_channel(self) -> AbstractChannel:
        return EcommerceChannel()

    def get_notifier(self) -> INotifiable:
        return EmailNotifier()


class LoggingNotifierDecorator(INotifiable):
    def __init__(self, wrapped: INotifiable) -> None:
        self._wrapped = wrapped
        self._logger = EventLogger()

    def notify(self, recipient: str, message: str) -> None:
        self._wrapped.notify(recipient, message)
        self._logger.log(f"Notificacion enviada a '{recipient}': {message}")


class OrderValidator:
    def validate(self, order: Order) -> tuple[bool, list[str]]:
        errors: list[str] = []
        if not order.origin or not order.origin.is_valid():
            errors.append("Direccion de origen invalida o fuera del dominio [1-100].")
        if not order.destination or not order.destination.is_valid():
            errors.append("Direccion de destino invalida o fuera del dominio [1-100].")
        if not order.recipient_name:
            errors.append("Falta nombre del destinatario.")
        if not order.contact_medium:
            errors.append("Falta medio de contacto.")
        if not order.delivery_type:
            errors.append("Falta tipo de entrega.")
        if not order.cargo_type:
            errors.append("Falta tipo de carga.")
        if order.weight_kg <= 0:
            errors.append("Peso debe ser mayor a 0.")
        if not order.order_id or not order.channel:
            errors.append("Falta ID unico o canal de origen.")
        return (len(errors) == 0, errors)


class OrderStateManager:
    _TRANSITIONS: dict[OrderStatus, list[OrderStatus]] = {
        OrderStatus.CREADO: [OrderStatus.VALIDADO, OrderStatus.CANCELADO],
        OrderStatus.VALIDADO: [OrderStatus.PENDIENTE_ASIGNACION, OrderStatus.CANCELADO],
        OrderStatus.PENDIENTE_ASIGNACION: [OrderStatus.ASIGNADO, OrderStatus.CANCELADO],
        OrderStatus.ASIGNADO: [OrderStatus.EN_RUTA, OrderStatus.PENDIENTE_ASIGNACION, OrderStatus.CANCELADO],
        OrderStatus.EN_RUTA: [OrderStatus.ENTREGADO, OrderStatus.INTENTO_FALLIDO, OrderStatus.CANCELADO],
        OrderStatus.INTENTO_FALLIDO: [OrderStatus.REPROGRAMADO, OrderStatus.CANCELADO],
        OrderStatus.REPROGRAMADO: [OrderStatus.ASIGNADO, OrderStatus.CANCELADO],
        OrderStatus.ENTREGADO: [],
        OrderStatus.CANCELADO: [],
    }

    def transition(self, order: Order, new_status: OrderStatus) -> bool:
        allowed = self._TRANSITIONS.get(order.status, [])
        if new_status in allowed:
            order.status = new_status
            order.add_event(f"Estado -> {new_status.value}")
            EventLogger().log(f"Pedido {order.order_id}: {new_status.value}")
            return True
        EventLogger().log(
            f"Transicion invalida: {order.status.value} -> {new_status.value} "
            f"(pedido {order.order_id})"
        )
        return False


@dataclass
class Courier:
    courier_id: int
    name: str
    max_volume_m3: float
    available: bool = True
    current_volume: float = 0.0
    current_orders: list[str] = field(default_factory=list)
    location: int = 50

    def can_accept(self, order_volume: float = 0.0) -> bool:
        return self.available and (self.current_volume + order_volume) <= self.max_volume_m3

    def assign_order(self, order_id: str, order_volume: float = 0.0) -> None:
        self.current_orders.append(order_id)
        self.current_volume += order_volume

    def update_location(self, loc: int) -> bool:
        if ROUTE_DOMAIN_MIN <= loc <= ROUTE_DOMAIN_MAX:
            self.location = loc
            return True
        return False


@dataclass
class Route:
    route_id: str
    order_ids: list[str] = field(default_factory=list)
    best_score: int = 0
    active: bool = True
    tracking_log: list[str] = field(default_factory=list)
