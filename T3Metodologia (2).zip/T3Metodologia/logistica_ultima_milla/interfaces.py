from .domain import (
    DeliveryType,
    EcommerceFactory,
    OrderStatus,
    PropioFactory,
)
from .services import LogisticsFacade


def _order_to_dict(order) -> dict:
    return {
        "order_id": order.order_id,
        "channel": order.channel.value,
        "status": order.status.value,
        "origin": {
            "calle": order.origin.street,
            "nro": order.origin.number,
            "ciudad": order.origin.city,
        } if order.origin else None,
        "destination": {
            "calle": order.destination.street,
            "nro": order.destination.number,
            "ciudad": order.destination.city,
        } if order.destination else None,
        "destinatario": order.recipient_name,
        "contacto": order.contact_medium,
        "tipo_entrega": order.delivery_type.value if order.delivery_type else None,
        "tipo_carga": order.cargo_type,
        "peso_kg": order.weight_kg,
        "repartidor_id": order.assigned_courier_id,
        "ruta_id": order.route_id,
        "eventos": order.events,
    }


def _courier_to_dict(courier) -> dict:
    return {
        "courier_id": courier.courier_id,
        "nombre": courier.name,
        "volumen_max": courier.max_volume_m3,
        "disponible": courier.available,
        "volumen_actual": courier.current_volume,
        "pedidos": courier.current_orders,
        "ubicacion": courier.location,
    }


def _route_to_dict(route) -> dict:
    return {
        "route_id": route.route_id,
        "pedidos": route.order_ids,
        "score": route.best_score,
        "activa": route.active,
        "seguimiento": route.tracking_log,
    }


def parse_order_factory(canal_str: str):
    if canal_str == "ECOMMERCE":
        return EcommerceFactory()
    return PropioFactory()


def cliente_crear_pedido(sistema: LogisticsFacade, order_id: str, data: dict) -> tuple[dict, int]:
    if not data:
        return {"success": False, "error": "Body JSON requerido."}, 400

    canal_str = data.get("canal", "CANAL_PROPIO").upper()
    factory = parse_order_factory(canal_str)

    tipo_str = data.get("tipo_entrega", "NORMAL").upper()
    try:
        delivery_type = DeliveryType(tipo_str)
    except ValueError:
        return {
            "success": False,
            "error": f"tipo_entrega invalido. Validos: {[e.value for e in DeliveryType]}",
        }, 422

    order = sistema.crear_pedido_con_factory(
        factory,
        order_id,
        data.get("origen", {}),
        data.get("destino", {}),
        data.get("destinatario", ""),
        data.get("contacto", ""),
        delivery_type,
        data.get("tipo_carga", ""),
        float(data.get("peso_kg", 0)),
    )

    ok, errors = sistema.validar_pedido(order_id)
    if not ok:
        return {"success": False, "order_id": order_id, "errores": errors}, 422

    sistema.asignar_pedido(order_id, order_volume=float(data.get("volumen_m3", 0.0)))
    sistema.notificar_cliente(order_id)

    return {
        "success": True,
        "canal": canal_str,
        "asignado": order.assigned_courier_id is not None,
        "order": _order_to_dict(order),
    }, 201


def cliente_tracking(sistema: LogisticsFacade, order_id: str) -> tuple[dict, int]:
    order = sistema.obtener_pedido(order_id)
    if not order:
        return {"success": False, "error": f"Pedido {order_id} no encontrado."}, 404

    resultado = _order_to_dict(order)
    if order.assigned_courier_id:
        courier = sistema.obtener_repartidor(order.assigned_courier_id)
        if courier:
            resultado["repartidor_info"] = {
                "nombre": courier.name,
                "ubicacion": courier.location,
            }
    return {"success": True, "tracking": resultado}, 200


def repartidor_registrar(sistema: LogisticsFacade, data: dict) -> tuple[dict, int]:
    nombre = data.get("nombre", "").strip()
    volumen_max = float(data.get("volumen_max", 0))

    if not nombre:
        return {"success": False, "error": "Campo 'nombre' requerido."}, 422
    if volumen_max <= 0:
        return {"success": False, "error": "volumen_max debe ser > 0."}, 422

    courier = sistema.registrar_repartidor(nombre, volumen_max)
    return {"success": True, "repartidor": _courier_to_dict(courier)}, 201


def repartidor_disponibilidad(sistema: LogisticsFacade, courier_id: int, data: dict) -> tuple[dict, int]:
    courier = sistema.obtener_repartidor(courier_id)
    if not courier:
        return {"success": False, "error": f"Repartidor {courier_id} no existe."}, 404

    disponible = bool(data.get("disponible", True))
    sistema.gestionar_disponibilidad(courier_id, disponible)
    return {"success": True, "repartidor": _courier_to_dict(courier)}, 200


def repartidor_ubicacion(sistema: LogisticsFacade, courier_id: int, data: dict) -> tuple[dict, int]:
    courier = sistema.obtener_repartidor(courier_id)
    if not courier:
        return {"success": False, "error": f"Repartidor {courier_id} no existe."}, 404

    loc = int(data.get("ubicacion", -1))
    ok = sistema.actualizar_ubicacion_repartidor(courier_id, loc)
    if not ok:
        return {"success": False,
                "error": f"Ubicacion {loc} fuera del dominio [1-100]."}, 400

    return {
        "success": True,
        "nota": "Consistencia eventual: estado no critico.",
        "repartidor": _courier_to_dict(courier),
    }, 200


def repartidor_cambiar_estado(sistema: LogisticsFacade, order_id: str, data: dict) -> tuple[dict, int]:
    ESTADOS_REPARTIDOR = ["EN_RUTA", "ENTREGADO", "INTENTO_FALLIDO"]
    status_str = data.get("status", "").upper()

    if status_str not in ESTADOS_REPARTIDOR:
        return {"success": False,
                "error": f"El repartidor solo puede cambiar a: {ESTADOS_REPARTIDOR}"}, 403

    try:
        new_status = OrderStatus(status_str)
    except ValueError:
        return {"success": False, "error": "Estado invalido."}, 422

    order = sistema.obtener_pedido(order_id)
    if not order:
        return {"success": False, "error": f"Pedido {order_id} no encontrado."}, 404

    ok = sistema.cambiar_estado(order_id, new_status)
    if not ok:
        permitidos = sistema.transiciones_permitidas(order_id)
        return {
            "success": False,
            "error": f"Transicion invalida desde '{order.status.value}'.",
            "estados_permitidos": permitidos,
        }, 400

    sistema.notificar_cliente(order_id)
    return {"success": True, "order": _order_to_dict(order)}, 200


def repartidor_ver_pedidos(sistema: LogisticsFacade, courier_id: int) -> tuple[dict, int]:
    courier = sistema.obtener_repartidor(courier_id)
    if not courier:
        return {"success": False, "error": f"Repartidor {courier_id} no existe."}, 404

    pedidos = [
        _order_to_dict(sistema.obtener_pedido(oid))
        for oid in courier.current_orders
        if sistema.obtener_pedido(oid)
    ]

    return {
        "success": True,
        "repartidor": courier.name,
        "ubicacion": courier.location,
        "pedidos": pedidos,
    }, 200


def sistema_asignar_pedido(sistema: LogisticsFacade, order_id: str, data: dict) -> tuple[dict, int]:
    order = sistema.obtener_pedido(order_id)
    if not order:
        return {"success": False, "error": f"Pedido {order_id} no encontrado."}, 404
    if order.status != OrderStatus.PENDIENTE_ASIGNACION:
        return {"success": False,
                "error": f"Pedido no esta en PENDIENTE_ASIGNACION (actual: {order.status.value})."}, 400

    volumen = float(data.get("volumen_m3", 0.0))
    if not sistema.hay_repartidores_disponibles(volumen):
        return {"success": False,
                "error": "Sin repartidores disponibles con capacidad suficiente."}, 409

    ok = sistema.asignar_pedido(order_id, order_volume=volumen)
    if not ok:
        return {"success": False, "error": "No se pudo asignar el pedido."}, 400

    courier = sistema.obtener_repartidor(order.assigned_courier_id) if order.assigned_courier_id else None
    return {
        "success": True,
        "order": _order_to_dict(order),
        "repartidor": _courier_to_dict(courier) if courier else None,
    }, 200


def sistema_definir_ruta(sistema: LogisticsFacade, data: dict) -> tuple[dict, int]:
    order_ids = data.get("order_ids", [])
    if not order_ids:
        return {"success": False, "error": "Se requiere al menos un pedido en 'order_ids'."}, 422

    no_existen = [oid for oid in order_ids if not sistema.obtener_pedido(oid)]
    if no_existen:
        return {"success": False, "error": f"Pedidos no encontrados: {no_existen}"}, 404

    ruta = sistema.definir_ruta(order_ids)
    return {"success": True, "ruta": _route_to_dict(ruta)}, 201


def sistema_listar_rutas(sistema: LogisticsFacade) -> tuple[dict, int]:
    rutas = sistema.listar_rutas()
    return {"success": True, "total": len(rutas), "rutas": [_route_to_dict(r) for r in rutas]}, 200


def sistema_ajustar_ruta(sistema: LogisticsFacade, route_id: str, data: dict) -> tuple[dict, int]:
    order_id = data.get("order_id", "").strip()
    if not order_id:
        return {"success": False, "error": "Campo 'order_id' requerido."}, 400

    ruta = sistema.obtener_ruta(route_id)
    if not ruta:
        return {"success": False, "error": f"Ruta {route_id} no encontrada."}, 404
    if not ruta.active:
        return {"success": False, "error": f"Ruta {route_id} no esta activa."}, 400
    if order_id in ruta.order_ids:
        return {"success": False, "error": f"Pedido {order_id} ya esta en la ruta."}, 409
    if not sistema.obtener_pedido(order_id):
        return {"success": False, "error": f"Pedido {order_id} no existe."}, 404

    ok = sistema.ajustar_ruta_dinamicamente(route_id, order_id)
    if not ok:
        return {"success": False, "error": "No se pudo ajustar la ruta."}, 400

    return {"success": True, "ruta": _route_to_dict(ruta)}, 200


def sistema_seguimiento_ruta(sistema: LogisticsFacade, route_id: str, data: dict) -> tuple[dict, int]:
    evento = data.get("evento", "").strip()
    if not evento:
        return {"success": False, "error": "Campo 'evento' requerido."}, 400

    ruta = sistema.obtener_ruta(route_id)
    if not ruta:
        return {"success": False, "error": f"Ruta {route_id} no encontrada."}, 404

    sistema.seguimiento_ruta(route_id, evento)
    return {"success": True, "ruta": _route_to_dict(ruta)}, 201


def admin_listar_repartidores(sistema: LogisticsFacade) -> tuple[dict, int]:
    couriers = sistema.listar_repartidores()
    return {"success": True, "total": len(couriers), "repartidores": [_courier_to_dict(c) for c in couriers]}, 200


def admin_listar_pedidos(sistema: LogisticsFacade) -> tuple[dict, int]:
    pedidos = sistema.listar_pedidos()
    return {"success": True, "total": len(pedidos), "pedidos": [_order_to_dict(o) for o in pedidos]}, 200


def admin_historial(sistema: LogisticsFacade) -> tuple[dict, int]:
    return {"success": True, "eventos": sistema.get_event_log()}, 200
