#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "LogisticsFacade.h"

namespace py = pybind11;
namespace ultima_milla = ultima_milla;

PYBIND11_MODULE(_logistica_cpp, m) {
    m.doc() = "C++ backend for logistica_ultima_milla";

    py::enum_<ultima_milla::OrderStatus>(m, "OrderStatus")
        .value("CREADO", ultima_milla::OrderStatus::CREADO)
        .value("VALIDADO", ultima_milla::OrderStatus::VALIDADO)
        .value("PENDIENTE_ASIGNACION", ultima_milla::OrderStatus::PENDIENTE_ASIGNACION)
        .value("ASIGNADO", ultima_milla::OrderStatus::ASIGNADO)
        .value("EN_RUTA", ultima_milla::OrderStatus::EN_RUTA)
        .value("INTENTO_FALLIDO", ultima_milla::OrderStatus::INTENTO_FALLIDO)
        .value("REPROGRAMADO", ultima_milla::OrderStatus::REPROGRAMADO)
        .value("ENTREGADO", ultima_milla::OrderStatus::ENTREGADO)
        .value("CANCELADO", ultima_milla::OrderStatus::CANCELADO)
        .export_values();

    py::enum_<ultima_milla::DeliveryType>(m, "DeliveryType")
        .value("NORMAL", ultima_milla::DeliveryType::NORMAL)
        .value("EXPRESS", ultima_milla::DeliveryType::EXPRESS)
        .value("PROGRAMADA", ultima_milla::DeliveryType::PROGRAMADA)
        .export_values();

    py::class_<ultima_milla::Address>(m, "Address")
        .def(py::init<>())
        .def_readwrite("street", &ultima_milla::Address::street)
        .def_readwrite("number", &ultima_milla::Address::number)
        .def_readwrite("city", &ultima_milla::Address::city)
        .def("is_valid", &ultima_milla::Address::is_valid);

    py::class_<ultima_milla::Order>(m, "Order")
        .def(py::init<>())
        .def_readwrite("order_id", &ultima_milla::Order::order_id)
        .def_readwrite("channel", &ultima_milla::Order::channel)
        .def_readwrite("origin", &ultima_milla::Order::origin)
        .def_readwrite("destination", &ultima_milla::Order::destination)
        .def_readwrite("recipient_name", &ultima_milla::Order::recipient_name)
        .def_readwrite("contact_medium", &ultima_milla::Order::contact_medium)
        .def_readwrite("delivery_type", &ultima_milla::Order::delivery_type)
        .def_readwrite("cargo_type", &ultima_milla::Order::cargo_type)
        .def_readwrite("weight_kg", &ultima_milla::Order::weight_kg)
        .def_readwrite("status", &ultima_milla::Order::status)
        .def_readwrite("assigned_courier_id", &ultima_milla::Order::assigned_courier_id)
        .def_readwrite("route_id", &ultima_milla::Order::route_id)
        .def_readwrite("events", &ultima_milla::Order::events)
        .def("add_event", &ultima_milla::Order::add_event);

    py::class_<ultima_milla::Courier>(m, "Courier")
        .def(py::init<>())
        .def_readwrite("courier_id", &ultima_milla::Courier::courier_id)
        .def_readwrite("name", &ultima_milla::Courier::name)
        .def_readwrite("max_volume_m3", &ultima_milla::Courier::max_volume_m3)
        .def_readwrite("available", &ultima_milla::Courier::available)
        .def_readwrite("current_volume", &ultima_milla::Courier::current_volume)
        .def_readwrite("current_orders", &ultima_milla::Courier::current_orders)
        .def_readwrite("location", &ultima_milla::Courier::location)
        .def("can_accept", &ultima_milla::Courier::can_accept)
        .def("assign_order", &ultima_milla::Courier::assign_order)
        .def("update_location", &ultima_milla::Courier::update_location);

    py::class_<ultima_milla::Route>(m, "Route")
        .def(py::init<>())
        .def_readwrite("route_id", &ultima_milla::Route::route_id)
        .def_readwrite("order_ids", &ultima_milla::Route::order_ids)
        .def_readwrite("best_score", &ultima_milla::Route::best_score)
        .def_readwrite("active", &ultima_milla::Route::active)
        .def_readwrite("tracking_log", &ultima_milla::Route::tracking_log);

    py::class_<ultima_milla::LogisticsFacade>(m, "LogisticsFacade")
        .def(py::init<>())
        .def("crear_pedido", &ultima_milla::LogisticsFacade::crear_pedido,
             py::arg("order_id"), py::arg("origin"), py::arg("destination"),
             py::arg("recipient_name"), py::arg("contact"), py::arg("delivery_type"),
             py::arg("cargo_type"), py::arg("weight_kg"), py::arg("channel"))
        .def("validar_pedido", &ultima_milla::LogisticsFacade::validar_pedido)
        .def("asignar_pedido", &ultima_milla::LogisticsFacade::asignar_pedido,
             py::arg("order_id"), py::arg("order_volume") = 0.0f)
        .def("definir_ruta", &ultima_milla::LogisticsFacade::definir_ruta)
        .def("ajustar_ruta_dinamicamente", &ultima_milla::LogisticsFacade::ajustar_ruta_dinamicamente)
        .def("seguimiento_ruta", &ultima_milla::LogisticsFacade::seguimiento_ruta)
        .def("obtener_pedido", &ultima_milla::LogisticsFacade::obtener_pedido)
        .def("obtener_repartidor", &ultima_milla::LogisticsFacade::obtener_repartidor)
        .def("obtener_ruta", &ultima_milla::LogisticsFacade::obtener_ruta);
}
