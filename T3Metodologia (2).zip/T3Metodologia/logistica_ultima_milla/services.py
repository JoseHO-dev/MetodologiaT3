from .domain import (
    AbstractOrderFactory,
    DeliveryType,
    EcommerceFactory,
    EventLogger,
    INotifiable,
    LoggingNotifierDecorator,
    Order,
    OrderStatus,
    OrderValidator,
    OrderStateManager,
    PropioFactory,
    Route,
)
from .repositories import CourierRepository, OrderRepository, RouteManager
from .background_queue import RouteTaskProcessor


class TrackingService:
    def __init__(self, order_repo: OrderRepository,
                 courier_repo: CourierRepository,
                 notifier: INotifiable) -> None:
        self._order_repo = order_repo
        self._courier_repo = courier_repo
        self._notifier = notifier

    def visualize_status(self, order_id: str) -> None:
        order = self._order_repo.get(order_id)
        if not order:
            print(f"  AVISO: Pedido {order_id} no encontrado.")
            return
        courier_info = "sin asignar"
        if order.assigned_courier_id:
            courier = self._courier_repo.get_by_id(order.assigned_courier_id)
            if courier:
                courier_info = f"{courier.name} (ID {courier.courier_id}, ubicacion: {courier.location})"
        print(f"  [{order.order_id}] {order.status.value} | Canal: {order.channel.value} | Repartidor: {courier_info}")

    def notify_client(self, order_id: str) -> None:
        order = self._order_repo.get(order_id)
        if not order:
            return
        self._notifier.notify(
            order.contact_medium,
            f"Tu pedido {order_id} esta en estado: {order.status.value}"
        )

    def record_event(self, order_id: str, event: str) -> None:
        order = self._order_repo.get(order_id)
        if order:
            order.add_event(event)
            EventLogger().log(f"Evento en {order_id}: {event}")


class LogisticsFacade:
    def __init__(self, order_repo: OrderRepository,
                 courier_repo: CourierRepository,
                 route_manager: RouteManager,
                 validator: OrderValidator,
                 state_manager: OrderStateManager,
                 tracking: TrackingService,
                 factory: AbstractOrderFactory,
                 route_task_processor: RouteTaskProcessor | None = None) -> None:
        self._order_repo = order_repo
        self._courier_repo = courier_repo
        self._route_manager = route_manager
        self._validator = validator
        self._state_manager = state_manager
        self._tracking = tracking
        self._factory = factory
        self._route_task_processor = route_task_processor
        self._logger = EventLogger()

    def crear_pedido(self, order_id: str, raw_origin: dict, raw_destination: dict,
                     recipient_name: str, contact: str, delivery_type: DeliveryType,
                     cargo_type: str, weight_kg: float) -> Order:
        order = self._factory.get_channel().create_order(
            order_id, raw_origin, raw_destination,
            recipient_name, contact, delivery_type, cargo_type, weight_kg
        )
        self._order_repo.save(order)
        self._logger.log(f"Pedido creado: {order_id} | Canal: {order.channel.value}")
        return order

    def crear_pedido_con_factory(self, factory: AbstractOrderFactory, order_id: str,
                                  raw_origin: dict, raw_destination: dict,
                                  recipient_name: str, contact: str,
                                  delivery_type: DeliveryType,
                                  cargo_type: str, weight_kg: float) -> Order:
        order = factory.get_channel().create_order(
            order_id, raw_origin, raw_destination,
            recipient_name, contact, delivery_type, cargo_type, weight_kg
        )
        self._order_repo.save(order)
        self._logger.log(f"Pedido creado: {order_id} | Canal: {order.channel.value}")
        return order

    def obtener_pedido(self, order_id: str) -> Order | None:
        return self._order_repo.get(order_id)

    def obtener_repartidor(self, courier_id: int):
        return self._courier_repo.get_by_id(courier_id)

    def obtener_ruta(self, route_id: str):
        return self._route_manager.get_route(route_id)

    def transiciones_permitidas(self, order_id: str) -> list[str]:
        order = self._order_repo.get(order_id)
        if not order:
            return []
        return [s.value for s in self._state_manager._TRANSITIONS.get(order.status, [])]

    def hay_repartidores_disponibles(self, order_volume: float = 0.0) -> bool:
        return bool(self._courier_repo.get_available(order_volume))

    def validar_pedido(self, order_id: str) -> tuple[bool, list[str]]:
        order = self._order_repo.get(order_id)
        if not order:
            return False, [f"Pedido {order_id} no existe."]
        ok, errors = self._validator.validate(order)
        if ok:
            # Only move to VALIDADO -> PENDIENTE_ASIGNACION when the order is newly created
            # to avoid reverting or interfering with later states (e.g., ASIGNADO, EN_RUTA).
            if order.status == OrderStatus.CREADO:
                self._state_manager.transition(order, OrderStatus.VALIDADO)
                self._state_manager.transition(order, OrderStatus.PENDIENTE_ASIGNACION)
        return ok, errors

    def cambiar_estado(self, order_id: str, new_status: OrderStatus) -> bool:
        order = self._order_repo.get(order_id)
        if not order:
            return False
        return self._state_manager.transition(order, new_status)

    def notificar_cliente(self, order_id: str) -> None:
        self._tracking.notify_client(order_id)

    def registrar_evento(self, order_id: str, event: str) -> None:
        self._tracking.record_event(order_id, event)

    def registrar_repartidor(self, name: str, max_volume_m3: float):
        return self._courier_repo.register(name, max_volume_m3)

    def gestionar_disponibilidad(self, courier_id: int, available: bool) -> None:
        self._courier_repo.set_availability(courier_id, available)

    def actualizar_ubicacion_repartidor(self, courier_id: int, location: int) -> bool:
        return self._courier_repo.update_location(courier_id, location)

    def asignar_pedido(self, order_id: str, order_volume: float = 0.0) -> bool:
        order = self._order_repo.get(order_id)
        if not order or order.status != OrderStatus.PENDIENTE_ASIGNACION:
            return False
        available = self._courier_repo.get_available(order_volume)
        if not available:
            return False
        courier = available[0]
        courier.assign_order(order_id, order_volume)
        order.assigned_courier_id = courier.courier_id
        self._state_manager.transition(order, OrderStatus.ASIGNADO)
        self._logger.log(
            f"Pedido {order_id} asignado a {courier.name} (ID={courier.courier_id}) "
            f"| vol={courier.current_volume:.2f}/{courier.max_volume_m3}m3"
        )
        return True

    def definir_ruta(self, order_ids: list[str]) -> Route:
        return self._route_manager.define_route(order_ids)

    def ajustar_ruta_dinamicamente(self, route_id: str, new_order_id: str) -> bool:
        if self._route_task_processor:
            return self._route_task_processor.enqueue_adjust_route(route_id, new_order_id)
        return self._route_manager.adjust_route(route_id, new_order_id, self._order_repo)

    def seguimiento_ruta(self, route_id: str, event: str) -> bool:
        if self._route_task_processor:
            return self._route_task_processor.enqueue_track_route(route_id, event)
        return self._route_manager.track_route(route_id, event)

    def listar_repartidores(self):
        return self._courier_repo.all()

    def listar_pedidos(self):
        return self._order_repo.all()

    def listar_rutas(self):
        return self._route_manager.all()

    def get_event_log(self) -> list[str]:
        return EventLogger().get_events()


def build_system(use_ecommerce: bool = False) -> LogisticsFacade:
    order_repo = OrderRepository()
    courier_repo = CourierRepository()
    route_manager = RouteManager()
    validator = OrderValidator()
    state_manager = OrderStateManager()
    factory = EcommerceFactory() if use_ecommerce else PropioFactory()
    notifier = LoggingNotifierDecorator(factory.get_notifier())
    tracking = TrackingService(order_repo, courier_repo, notifier)
    route_task_processor = RouteTaskProcessor(route_manager, order_repo)
    return LogisticsFacade(order_repo, courier_repo, route_manager,
                           validator, state_manager, tracking, factory,
                           route_task_processor)
