"""Logistica de Ultima Milla - Paquete de dominio, repositorios y servicios."""

from .domain import (
    Address,
    AbstractChannel,
    AbstractOrderFactory,
    Channel,
    DeliveryType,
    EcommerceChannel,
    EcommerceFactory,
    EventLogger,
    ExternalAddressAdapter,
    INotifiable,
    LoggingNotifierDecorator,
    Order,
    OrderBuilder,
    OrderStatus,
    OrderValidator,
    OrderStateManager,
    PropioChannel,
    PropioFactory,
    Route,
)
from .repositories import CourierRepository, OrderRepository, RouteManager
from .services import LogisticsFacade, TrackingService, build_system

try:
    from ._logistica_cpp import LogisticsFacade as CppLogisticsFacade
except ImportError:
    CppLogisticsFacade = None

#TODO: descripcion textualdel modulo logistica_ultima_milla: el modulo se encarga de la logistica de ultima milla, incluyendo la gestion de pedidos, rutas y notificaciones. Proporciona clases y servicios para manejar direcciones, canales de venta, tipos de entrega, validacion de pedidos y seguimiento de envios. Ademas, incluye repositorios para almacenar informacion sobre mensajeros, pedidos y rutas, asi como un facade para simplificar la interaccion con el sistema logistico.
#TODO: Entre los servicios que ofrece esta el seguimiento de envios, la gestion de rutas y la notificacion a los clientes sobre el estado de sus pedidos. El modulo esta diseñado para ser flexible y extensible, permitiendo la integracion con diferentes canales de venta y tipos de entrega, asi como la adaptacion a diferentes necesidades logisticas.

def build_system_cpp():
    if CppLogisticsFacade is None:
        raise ImportError(
            "C++ extension _logistica_cpp not found. Build it with `python setup.py install` or `pip install -e .`."
        )
    return CppLogisticsFacade()

__all__ = [
    "Address",
    "AbstractChannel",
    "AbstractOrderFactory",
    "Channel",
    "DeliveryType",
    "EcommerceChannel",
    "EcommerceFactory",
    "EventLogger",
    "ExternalAddressAdapter",
    "INotifiable",
    "LoggingNotifierDecorator",
    "Order",
    "OrderBuilder",
    "OrderStatus",
    "OrderValidator",
    "OrderStateManager",
    "PropioChannel",
    "PropioFactory",
    "Route",
    "CourierRepository",
    "OrderRepository",
    "RouteManager",
    "LogisticsFacade",
    "TrackingService",
    "build_system",
    "build_system_cpp",
]
