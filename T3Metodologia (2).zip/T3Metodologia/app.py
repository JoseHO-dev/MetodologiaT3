"""
Logistica de Ultima Milla - Presentacion / API web

La capa de presentacion expone endpoints Flask que delegan
la logica de negocio a la capa de interfaz.
"""

from flask import Flask, request, jsonify
from functools import wraps
from logistica_ultima_milla import build_system
import logistica_ultima_milla.interfaces as interfaces

app = Flask(__name__)

# =============================================================================
# DEPENDENCY INJECTION
# =============================================================================
sistema = build_system(use_ecommerce=False)
_order_counter = [0]


def get_user_role() -> str:
    return request.headers.get("X-User-Role", "guest").strip().lower()


def require_roles(*allowed_roles):
    allowed = {role.lower() for role in allowed_roles}

    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            role = get_user_role()
            if role not in allowed:
                return jsonify({
                    "success": False,
                    "error": "Acceso denegado",
                    "required_roles": list(allowed),
                    "received_role": role,
                }), 403
            return fn(*args, **kwargs)
        return wrapper
    return decorator

# =============================================================================
# DISPONIBILIDAD CONTINUA: manejo global de excepciones
# =============================================================================

@app.errorhandler(Exception)
def handle_exception(e):
    return jsonify({
        "success": False,
        "error":   f"Error interno del servidor: {str(e)}",
        "hint":    "El servicio sigue operativo."
    }), 500

@app.errorhandler(404)
def not_found(e):
    return jsonify({"success": False, "error": "Endpoint no encontrado."}), 404

@app.errorhandler(405)
def method_not_allowed(e):
    return jsonify({"success": False, "error": "Metodo HTTP no permitido."}), 405


# =============================================================================
# Verificar que el sistema funciona correctamente
# =============================================================================

@app.route("/", methods=["GET"])
@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "service": "Logistica de Ultima Milla - Web Service",
        "version": "2.0",
        "status":  "running",
        "roles": {
            "cliente":    "Crear pedidos y ver su propio tracking",
            "repartidor": "Registrarse, gestionar disponibilidad, actualizar ubicacion y estado de pedidos",
            "sistema":    "Asignar pedidos y gestionar rutas",
            "admin":      "Ver historial de eventos y listar repartidores/pedidos",
            "venta":      "Crear pedidos via canal e-commerce",
        },
        "endpoints": {
            "cliente":    ["POST /cliente/pedidos",
                           "GET  /cliente/tracking/<id>"],
            "repartidor": ["POST /repartidor/registrar",
                           "PUT  /repartidor/disponibilidad/<id>",
                           "PUT  /repartidor/ubicacion/<id>",
                           "PUT  /repartidor/pedidos/<id>/estado",
                           "GET  /repartidor/pedidos?courier_id=<id>"],
            "sistema":    ["POST /sistema/pedidos/<id>/asignar",
                           "POST /sistema/rutas",
                           "GET  /sistema/rutas",
                           "POST /sistema/rutas/<id>/ajustar",
                           "POST /sistema/rutas/<id>/seguimiento"],
            "admin":      ["GET  /admin/repartidores",
                           "GET  /admin/pedidos",
                           "GET  /admin/eventos"],
        }
    }), 200


# =============================================================================
# CLIENTE
# Crear pedido 
# Ver su propio tracking
# =============================================================================

@app.route("/cliente/pedidos", methods=["POST"])
@require_roles("cliente", "admin")
def cliente_crear_pedido():
    data = request.get_json(silent=True)
    _order_counter[0] += 1
    order_id = f"PED-{_order_counter[0]:03d}"
    payload, status = interfaces.cliente_crear_pedido(sistema, order_id, data)
    return jsonify(payload), status


@app.route("/cliente/tracking/<order_id>", methods=["GET"])
@require_roles("cliente", "admin")
def cliente_tracking(order_id):
    payload, status = interfaces.cliente_tracking(sistema, order_id)
    return jsonify(payload), status


# =============================================================================
# REPARTIDOR
# Registrarse, gestionar disponibilidad, actualizar ubicaci�n
# Cambiar estado del pedido (EN_RUTA, ENTREGADO, INTENTO_FALLIDO)
# Ve sus pedidos asignados
# =============================================================================

@app.route("/repartidor/registrar", methods=["POST"])
@require_roles("guest", "repartidor", "admin")
def repartidor_registrar():
    data = request.get_json(silent=True) or {}
    payload, status = interfaces.repartidor_registrar(sistema, data)
    return jsonify(payload), status


@app.route("/repartidor/disponibilidad/<int:courier_id>", methods=["PUT"])
@require_roles("repartidor", "admin")
def repartidor_disponibilidad(courier_id):
    data = request.get_json(silent=True) or {}
    payload, status = interfaces.repartidor_disponibilidad(sistema, courier_id, data)
    return jsonify(payload), status


@app.route("/repartidor/ubicacion/<int:courier_id>", methods=["PUT"])
@require_roles("repartidor", "admin")
def repartidor_ubicacion(courier_id):
    data = request.get_json(silent=True) or {}
    payload, status = interfaces.repartidor_ubicacion(sistema, courier_id, data)
    return jsonify(payload), status


@app.route("/repartidor/pedidos/<order_id>/estado", methods=["PUT"])
@require_roles("repartidor", "admin")
def repartidor_cambiar_estado(order_id):
    data = request.get_json(silent=True) or {}
    payload, status = interfaces.repartidor_cambiar_estado(sistema, order_id, data)
    return jsonify(payload), status


@app.route("/repartidor/pedidos", methods=["GET"])
@require_roles("repartidor", "admin")
def repartidor_ver_pedidos():
    courier_id = request.args.get("courier_id", type=int)
    if not courier_id:
        return jsonify({
            "success": False,
            "error": "Query param requerido. Ej: /repartidor/pedidos?courier_id=1"
        }), 400
    payload, status = interfaces.repartidor_ver_pedidos(sistema, courier_id)
    return jsonify(payload), status


# =============================================================================
# SISTEMA 
# Asigna pedidos
# Gestiona rutas
# =============================================================================

@app.route("/sistema/pedidos/<order_id>/asignar", methods=["POST"])
@require_roles("sistema", "admin")
def sistema_asignar_pedido(order_id):
    data = request.get_json(silent=True) or {}
    payload, status = interfaces.sistema_asignar_pedido(sistema, order_id, data)
    return jsonify(payload), status


@app.route("/sistema/rutas", methods=["POST"])
@require_roles("sistema", "admin")
def sistema_definir_ruta():
    data = request.get_json(silent=True) or {}
    payload, status = interfaces.sistema_definir_ruta(sistema, data)
    return jsonify(payload), status


@app.route("/sistema/rutas", methods=["GET"])
@require_roles("sistema", "admin")
def sistema_listar_rutas():
    payload, status = interfaces.sistema_listar_rutas(sistema)
    return jsonify(payload), status


@app.route("/sistema/rutas/<route_id>/ajustar", methods=["POST"])
@require_roles("sistema", "admin")
def sistema_ajustar_ruta(route_id):
    data = request.get_json(silent=True) or {}
    payload, status = interfaces.sistema_ajustar_ruta(sistema, route_id, data)
    return jsonify(payload), status


@app.route("/sistema/rutas/<route_id>/seguimiento", methods=["POST"])
@require_roles("sistema", "admin")
def sistema_seguimiento_ruta(route_id):
    data = request.get_json(silent=True) or {}
    payload, status = interfaces.sistema_seguimiento_ruta(sistema, route_id, data)
    return jsonify(payload), status


# =============================================================================
# ADMIN
# Solo vista: pedidos, repartidores, historial de eventos
# =============================================================================

@app.route("/admin/repartidores", methods=["GET"])
@require_roles("admin")
def admin_listar_repartidores():
    payload, status = interfaces.admin_listar_repartidores(sistema)
    return jsonify(payload), status


@app.route("/admin/pedidos", methods=["GET"])
@require_roles("admin")
def admin_listar_pedidos():
    payload, status = interfaces.admin_listar_pedidos(sistema)
    return jsonify(payload), status


@app.route("/admin/eventos", methods=["GET"])
@require_roles("admin")
def admin_historial():
    payload, status = interfaces.admin_historial(sistema)
    return jsonify(payload), status


# =============================================================================
# CARGA VARIABLE � threaded=True permite m�ltiples requests simultaneos
# =============================================================================

if __name__ == "__main__":
    print("\n" + "="*60)
    print("  Logistica de Ultima Milla - Web Service v2.0")
    print("  http://localhost:5000")
    print("  /cliente  /repartidor  /sistema  /admin ")
    print("="*60 + "\n")
    app.run(debug=True, host="0.0.0.0", port=5000, threaded=True)
