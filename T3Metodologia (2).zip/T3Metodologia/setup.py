import os
from setuptools import setup, Extension
import pybind11

ext_modules = [
    Extension(
        "logistica_ultima_milla._logistica_cpp",
        sources=[
            os.path.join("logistica_ultima_milla", "LogisticsFacade.cpp"),
            os.path.join("logistica_ultima_milla", "pybind_module.cpp"),
        ],
        include_dirs=[pybind11.get_include()],
        language="c++",
        extra_compile_args=["/std:c++17"] if os.name == "nt" else ["-std=c++17"],
    )
]

setup(
    name="T3Metodologia",
    version="0.1.0",
    description="Logistica de Ultima Milla con binding C++",
    packages=["logistica_ultima_milla"],
    ext_modules=ext_modules,
    zip_safe=False,
)
