## Requisitos
pip install flask

## Ejecutar
python app.py
→ http://localhost:5000 
→ abrir postman y hacer los post/get/put necesarios

## Estructura en capas
- `app.py`: capa de presentación (Flask) y enrutamiento.
- `logistica_ultima_milla/interfaces.py`: capa de interfaz, validación de peticiones JSON, armado de respuestas y coordinación del servicio.
- `logistica_ultima_milla/services.py`: capa de servicios, fachada y lógica de gestión.
- `logistica_ultima_milla/domain.py`: capa de dominio, entidades, valor-objeto, patrones de fábrica y reglas de negocio.
- `logistica_ultima_milla/repositories.py`: repositorios de pedidos, repartidores y rutas.

## Roles y prefijos de los URL
| Prefijo         | Quién lo usa                  | Qué puede hacer                                      |
|-----------------|-------------------------------|------------------------------------------------------|
| /cliente/...    | Cliente final                 | Crear pedido, ver tracking propio                    |
| /repartidor/... | Repartidor                    | Registrarse, disponibilidad, ubicacion, estado pedido|
| /sistema/...    | Operador logístico            | Asignar pedidos, definir/ajustar rutas               |
| /admin/...      | Administrador                 | Ver pedidos, repartidores, historial (solo lectura)  |

## Roles y prefijos de URL
| Prefijo         | Quién lo usa                  | Qué puede hacer                                                        
|-----------------|-------------------------------|------------------------------------------------------------------------     
| /cliente/...    | Cliente final                 | Crear pedido por canal, ver tracking propio                                 
| /repartidor/... | Repartidor                    | Registrarse, disponibilidad, actualizar ubicación, cambiar estado de pedido 
| /sistema/...    | Sistema logistico             | Asignar pedidos, definir rutas, ajustar rutas, registrar seguimiento        
| /admin/...      | Administrador                 | Ver pedidos, repartidores, historial de eventos (solo lectura)         